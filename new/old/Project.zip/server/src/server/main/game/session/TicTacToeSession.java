package server.main.game.session;

import rmigameclient.RMIGameClient;
import rmigamesession.RMIGameSession;
import server.main.MainServer;
import server.main.SupportedGames;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;


// this class implements the remove RMI interface which handles
// the game logic in a tictactoe game instance.
public class TicTacToeSession implements RMIGameSession {
    // remote players participating in current game session
    private RMIGameClient player1;
    private RMIGameClient player2;
    private String player1UserName;
    private String player2UserName;
    private int id1;
    private int id2;
    private int p1Score, p2Score;

    // player turn flag
    private boolean turnP1 = true;

    // end of game flags
    private boolean playable = true;
    private boolean p1Ready, p2Ready;
    private boolean p1Won = false;
    private boolean p2Won = false;

    // board game data
    private final Tile[][] board;
    private final List<Combo> combos = new ArrayList<>();
    private int moveCount;
    private final int MAXMOVE = 9;

    // stub of parent main server
    private MainServer mainServer;
    private boolean updateSQLScore = false;
    private final Object lock = new Object();
    private boolean sessionEnded = false;
    private Thread ping;

    public void setPlayer1(RMIGameClient player1) {
        this.player1 = player1;
    }

    public void setPlayer2(RMIGameClient player2) {
        this.player2 = player2;
    }


    // board initialization
    public TicTacToeSession() {
        board = new Tile[3][3];
        for (int c = 0; c < 3; c++)
            for (int r = 0; r < 3; r++) {
                board[r][c] = new Tile(r, c);
            }
        //horizontal
        for (int c = 0; c < 3; c++)
            combos.add(new Combo(
                    board[0][c],
                    board[1][c],
                    board[2][c]));
        //vertical
        for (int r = 0; r < 3; r++)
            combos.add(new Combo(
                    board[r][0],
                    board[r][1],
                    board[r][2]));
        //diagonals
        combos.add(new Combo(
                board[0][0],
                board[1][1],
                board[2][2]));
        combos.add(new Combo(
                board[2][0],
                board[1][1],
                board[0][2]));
    }

    public TicTacToeSession(RMIGameClient player1, RMIGameClient player2, MainServer mainServer) {
        this();
        this.mainServer = mainServer;
        this.player1 = player1;
        this.id1 = player1.hashCode();
        p1Score = p2Score = 0;
        this.player2 = player2;
        this.id2 = player2.hashCode();
        p1Ready = p2Ready = true;

        try {
            player1UserName = player1.getUserName();
            player2UserName = player2.getUserName();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        // connection testing daemon thread
        // used to identify unexpected player disconnections
        ping = new Thread(() -> {
            while (!sessionEnded) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    if (sessionEnded)
                        return;
                }
                try {
                    player1.ping();
                } catch (RemoteException e) {
                    try {
                        // update sql score
                       /* mainServer.updateSQLUser(player1UserName,
                                p1Score,
                                p2Score,
                                SupportedGames.TICTAKTOE);
                        mainServer.updateSQLUser(player2UserName,
                                p2Score,
                                p1Score,
                                SupportedGames.TICTAKTOE);*/
                        player2.opponentDisconnected();
                        return;
                    } catch (RemoteException remoteException) {
                        remoteException.printStackTrace();
                        System.err.println("player1 disconnected on session: " + this);
                    }
                    e.printStackTrace();
                    return;
                }
                try {
                    player2.ping();
                } catch (RemoteException e) {
                    try {
                        // update sql score
                        /*mainServer.updateSQLUser(player1UserName,
                                p1Score,
                                p2Score,
                                SupportedGames.TICTAKTOE);
                        mainServer.updateSQLUser(player2UserName,
                                p2Score,
                                p1Score,
                                SupportedGames.TICTAKTOE);*/
                        player1.opponentDisconnected();
                        return;
                    } catch (RemoteException remoteException) {
                        System.err.println("player2 disconnected on session: " + this);
                        remoteException.printStackTrace();
                    }
                    e.printStackTrace();
                    return;
                }

            }
        });
        ping.setDaemon(true);
        ping.start();
       /*ScheduledExecutorService scheduler =
                Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {
            while (true) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                try {
                    player1.ping();
                } catch (RemoteException e) {
                    try {
                        player2.opponentDisconnected();
                        return;
                    } catch (RemoteException remoteException) {
                        remoteException.printStackTrace();
                    }
                    e.printStackTrace();
                    return;
                }
                try {
                    player2.ping();
                } catch (RemoteException e) {
                    try {
                        player1.opponentDisconnected();
                        return;
                    } catch (RemoteException remoteException) {
                        remoteException.printStackTrace();
                    }
                    e.printStackTrace();
                    return;
                }

            }
        }, 0, 5, TimeUnit.SECONDS);*/

        // sql table update daemon thread.
        // notified on gameover event by method reset()
        new Thread(() -> {
            while (true) {
                synchronized (lock) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("done waiting");
                    mainServer.updateSQLUser(player1UserName,
                            p1Won ? 1 : 0,
                            p2Won ? 1 : 0,
                            SupportedGames.TICTAKTOE);
                    mainServer.updateSQLUser(player2UserName,
                            p2Won ? 1 : 0,
                            p1Won ? 1 : 0,
                            SupportedGames.TICTAKTOE);
                    p1Won = p2Won = false;
                    updateSQLScore = false;
                }

            }
        }).start();
    }


    // remote method for registering new move by remote client
    @Override
    public synchronized boolean move(int c, int r, int id) throws RemoteException {
        boolean valid = false;
        // check if tile is occupied or game is playable
        if (board[r][c].getValue() != 0
                || !playable)
            return false;
        if (id == id1 && turnP1) {
            //p1 turn
            valid = true;
            moveCount++;
            player2.update(c, r);
            board[r][c].setValue(1);
            turnP1 = false;
        }
        if (id == id2 && !turnP1) {
            //p2 turn
            valid = true;
            moveCount++;
            player1.update(c, r);
            board[r][c].setValue(2);
            turnP1 = true;
        }
        // check if current move is a winning move
        if (checkState()) {
            int winningID;
            if (id == id1) {
                p1Score++;
                winningID = id1;
            } else {
                p2Score++;
                winningID = id2;
            }
            gameOver(winningID);
        }
        // in case of a draw
        if (playable && moveCount == MAXMOVE) {
            gameOver(-1);

        }
        return valid;
    }


    // remote method used by main server to set and send game info
    // to the participating players
    @Override
    public void sendConnectionInfo(String msg) {
        try {
            player1.setConnectionInfo(msg, id1, "X");
            player2.setConnectionInfo(msg, id2, "O");
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    // checks for a winning combo
    private boolean checkState() {
        for (Combo combo : combos) {
            if (combo.isComplete()) {
                int[] start = combo.tiles[0].getPos();
                int[] end = combo.tiles[2].getPos();
                try {
                    player1.playGameOverRoutine(start, end);
                    player2.playGameOverRoutine(start, end);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
                return true;
            }
        }
        return false;
    }

    private class Combo {
        final Tile[] tiles;

        public Combo(Tile... tiles) {
            this.tiles = tiles;
        }

        public boolean isComplete() {
            if (tiles[0].getValue() == 0)
                return false;
            return tiles[0].getValue() == (tiles[1].getValue())
                    && tiles[0].getValue() == (tiles[2].getValue());
        }
    }


    // tile data class
    private class Tile {
        int value;
        final int r;
        final int c;

        public Tile(int r, int c) {
            this.r = r;
            this.c = c;
        }

        public void setValue(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }

        public int[] getPos() {
            return new int[]{r, c};
        }
    }

    // used by client to update in case of disconnection
    @Override
    public void sessionEnded(int id) throws RemoteException {
        if (id1 == id)
            player2.opponentDisconnected();
        else if (id2 == id)
            player1.opponentDisconnected();
        sessionEnded = true;
        ping.interrupt();
    }

    public void gameOver(int winningID) throws RemoteException {
        player1.showGameOverMessage(id1 == winningID, p1Score, p2Score);
        player2.showGameOverMessage(id2 == winningID, p2Score, p1Score);
        p1Won = winningID == id1;
        p2Won = winningID == id2;
        reset();
    }

    // reset game
    public void reset() {
        for (int c = 0; c < 3; c++)
            for (int r = 0; r < 3; r++) {
                board[r][c].setValue(0);
            }
        turnP1 = true;
        moveCount = 0;
        playable = false;
        p1Ready = p2Ready = false;
        //toggle status
        updateSQLScore = true;
        synchronized (lock) {
            lock.notifyAll();
        }
    }

    // remote method used by client to update server
    @Override
    public void setPlayerReady(int id) throws RemoteException {
        if (id == id1)
            p1Ready = true;
        if (id == id2)
            p2Ready = true;
        if (p1Ready && p2Ready)
            playable = true;
    }


    // used by session to update the other player regurding
    // new message.
    @Override
    public void sendChatMessage(int id, String msg) {
        if (id == id1) {
            try {
                player2.recieveChatMessage(player1UserName + ": " + msg);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        } else if (id == id2)
            try {
                player1.recieveChatMessage(player2UserName + ": " + msg);
            } catch (RemoteException e) {
                e.printStackTrace();
            }

    }


    // remote method for connection testing
    @Override
    public void ping() throws RemoteException {
    }
}